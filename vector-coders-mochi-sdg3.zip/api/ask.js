// Vercel serverless function: keeps the Anthropic API key secret (never put the key in the browser or repo).
const hits = new Map(); // tiny per-IP rate limit (resets when the function cold-starts)
const SYSTEM = `You are Mochi, a cheerful pet and health ambassador for UN Sustainable Development Goal 3 (Good Health and Well-being).
Answer in 1-3 short, friendly sentences for children aged 8-14, with one accurate, practical health fact.
Link to SDG 3 where natural. You are not a doctor: for illness, injury, self-harm, abuse or anything serious, say to talk to a trusted adult or doctor right away.
Never give medicine doses or diagnoses. Politely steer unrelated or inappropriate questions back to healthy living.`;

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", process.env.ALLOWED_ORIGIN || "*");
  res.setHeader("Access-Control-Allow-Headers", "content-type");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });

  const ip = req.headers["x-forwarded-for"] || "anon";
  const n = (hits.get(ip) || 0) + 1; hits.set(ip, n);
  if (n > 60) return res.status(429).json({ error: "Too many questions, try later" });

  const q = String(req.body?.q || "").slice(0, 200).trim();
  if (!q) return res.status(400).json({ error: "Missing q" });

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: process.env.MODEL || "claude-haiku-5-5", max_tokens: 200, system: SYSTEM,
        messages: [{ role: "user", content: q }] }),
    });
    const d = await r.json();
    const answer = d.content?.map(b => b.text || "").join("").trim();
    if (!answer) return res.status(502).json({ error: "No answer" });
    res.status(200).json({ answer });
  } catch (e) { res.status(500).json({ error: "Server error" }); }
}
