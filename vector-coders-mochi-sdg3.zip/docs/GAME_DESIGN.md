# Game Design Document: Mochi, Health Ambassador
Team: **Vector Coders** · Theme: **UN SDG 3 Good Health and Well-being**

## 1. Problem and SDG interpretation (10)
Many children lack health knowledge, clean water or access to care. The game teaches habits through caring for a pet and mirrors four SDG 3 targets, tracked live on screen:
| Target | In the game |
|---|---|
| 3.3 End epidemics, fight communicable disease | Handwashing mini-game, vaccination, Flu season event |
| 3.4 Non-communicable disease and mental health | Healthy food, exercise, sleep, Talk (kind replies), Exam stress event |
| 3.8 Universal health coverage | Clinic (check-up), Free clinic day event |
| 3.9 Illness from unsafe water | Clean water choice, Dirty water alert event |
Mochi wears a UN-blue scarf; the UI uses the SDG 3 green (#4C9F38) and UN blue (#009EDB). Official SDG logos are not reproduced.

## 2. Story
Mochi joins your village as its health ambassador. Over 7 days (45 s each) you keep Mochi healthy and handle village health events. Win: finish day 7. Lose: health ≤ 15%.

## 3. Core loop and mechanics (20 / 15)
Stats decay → read Mochi's cues and the daily event → act → stats rise, fact appears, target bars grow.
- **Stats:** Food, Energy, Clean, Fitness, Mood. Health = average.
- **Actions:** Feed (healthy vs junk, 3 treats a day = tummy ache), Wash (tap mini-game), Exercise (6 s tap mini-game), Talk (choose supportive reply), Clinic (vaccine or check-up, once a day), Sleep.
- **Daily events (day 2–7):** each has a goal tied to a target. Clear it for +25 target points; fail it for a mood and energy penalty.
- **Score:** health×2 + target points + facts×5 + 100 win bonus. Best score saved. 🏅 badges for each target ≥ 50.

## 4. Creativity and innovation (15)
- **Ask Mochi:** a child-safe Claude AI gives customised facts for any question, with an offline fallback.
- Pet-care loop reframed as a village health-policy simulation (events, vaccination, clinic access).
- Mochi's body colour, face and dirt show health visually; players read the state, not just bars.

## 5. Technical implementation (20)
Static HTML/CSS/JS (no dependencies) + one serverless function (`api/ask.js`). Web Audio API sounds, Speech Synthesis voice, localStorage best score, graceful AI fallback, API key kept server-side, input limits and rate limiting. See `docs/AI_SETUP.md`.

## 6. Visual and audio (10)
SDG-green header with goal tile, UN-blue accents, day/night scene, dark-mode support, synthesised sound effects and day-end jingle, mute button. `prefers-reduced-motion` respected.

## 7. Accessibility
Keyboard-operable buttons with focus rings, `aria-live` speech bubble, labelled controls, high-contrast text, mobile-first layout.

## 8. Testing
Playtested flows: win, lose, junk-food penalty, each event pass/fail, AI online and offline. Tune difficulty in `tick()` and `EV`.
