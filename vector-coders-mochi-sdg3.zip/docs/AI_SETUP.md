# Enabling "Ask Mochi" (AI)
The game works without AI (offline answers). To turn on real AI answers:
1. Get an API key at https://console.anthropic.com.
2. Create a free account at https://vercel.com and import this GitHub repo.
3. In Vercel → Settings → Environment Variables add `ANTHROPIC_API_KEY` (optional: `MODEL`, `ALLOWED_ORIGIN` = your GitHub Pages URL). Deploy.
4. Copy your URL (`https://<project>.vercel.app/api/ask`) into `MOCHI_API_URL` at the top of the script in `index.html`, commit, done.

**Safety:** the key lives only on the server. The system prompt keeps answers child-friendly, says Mochi is not a doctor, and redirects serious issues to a trusted adult. Input is limited to 200 characters and 60 requests per visitor.
**Fallback:** if the API is missing, slow (9 s) or errors, the game shows a curated answer tagged "Offline".
