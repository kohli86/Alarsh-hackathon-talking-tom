# 3-minute pitch outline (Vector Coders)
1. **Hook (20 s):** "Every year millions of children fall ill from things we already know how to prevent."
2. **SDG 3 and our targets (30 s):** show target bars 3.3 / 3.4 / 3.8 / 3.9.
3. **Live demo (90 s):** feed healthy vs junk → handwash → flu event → vaccinate at clinic → Talk → ask the AI "I have exams, I'm stressed".
4. **Tech (30 s):** static game, serverless AI proxy keeps the key safe, offline fallback, Web Audio.
5. **Impact and next steps (10 s):** more languages, school classroom mode, more targets (3.7, 3.d).
