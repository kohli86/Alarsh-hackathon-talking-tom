# 🐾 Mochi: Health Ambassador
**Team Vector Coders** · Game for **UN SDG 3: Good Health and Well-being**

A Talking Tom-style virtual pet that turns SDG 3 into gameplay. Keep Mochi healthy for 7 days, clear village health events, and ask Mochi any health question using AI.

▶ **Play:** open `index.html`, or enable GitHub Pages (Settings → Pages → `main` / root).

## Features
- 5 stats, 6 actions, 2 tap mini-games, daily events, 7-day story with win/lose endings
- Live progress on SDG targets **3.3, 3.4, 3.8, 3.9** with badges and best score
- **Ask Mochi:** AI answers any health question in a child-safe way (offline fallback included)
- Sound effects, voice, day/night, dark mode, mobile and keyboard friendly

## How to play
| Action | Effect | Target |
|---|---|---|
| 🍎 Feed | Healthy food, water or junk | 3.4, 3.9 |
| 🧼 Wash | Scrub 10 times | 3.3 |
| 🏃 Exercise | 6-second tapping game | 3.4 |
| 💬 Talk | Pick the kind reply | 3.4 |
| 🏥 Clinic | Vaccine or check-up, once a day | 3.3, 3.8 |
| 😴 Sleep | Restore energy | 3.4 |
Tap Mochi to play. Check the event banner each day for the goal. Type in the box and press 🤖 for AI facts or 🔊 to make Mochi repeat you.

## Project structure
```
index.html           game (HTML/CSS/JS, no dependencies)
api/ask.js           serverless AI proxy (Vercel)
docs/GAME_DESIGN.md  design, SDG mapping, judging notes
docs/AI_SETUP.md     enable the AI in 4 steps
docs/PRESENTATION.md pitch outline
```
## Setup
No install needed. For AI answers follow [docs/AI_SETUP.md](docs/AI_SETUP.md). Never commit an API key.

## Credits
Built by Vector Coders. Not affiliated with the United Nations; SDG colours are used to show the goal. MIT License.
